import java.util.function.Function;

public class generate {
    static String generateCaptcha(int n){
        String chrs = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        String captcha = "";
        while (n-- > 0){
            int index = (int)(Math.random()*62);
            captcha += chrs.charAt(index);
        }
        return captcha;
    }

    public String getCaptcha(){
        Function<String, String> formatter = s -> s;
        return formatter.apply(generateCaptcha(5));
    }
}