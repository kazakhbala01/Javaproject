public class Main {
    public static void main(String[] args) {
        LoginFrame frame1 = new LoginFrame();
        frame1.Loginframe();
    }
}