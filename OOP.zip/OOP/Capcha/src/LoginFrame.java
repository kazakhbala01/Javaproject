import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

public class LoginFrame extends JFrame {
    public void Loginframe() {
        LoginPanel loginPanel = new LoginPanel();
        add(loginPanel);

        setTitle("Login");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

    }
    public void captcha(String realc){
            JFrame frame = new JFrame("JLabel");
            frame.setLayout(null);
            frame.setVisible(true);
            frame.setBounds(100, 200, 400, 400);
            Container c = frame.getContentPane();
            String captcha = realc;
            JLabel obj1 = new JLabel(captcha);
            obj1.setBounds(100, 100, 300, 30);
            obj1.setFont(new Font("Monospaced", Font.ITALIC, 30));
            c.add(obj1);
    }
}
