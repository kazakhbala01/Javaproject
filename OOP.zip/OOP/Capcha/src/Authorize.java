import javax.swing.*;
import java.awt.*;

public class Authorize extends Component {
    public void Authorize1(){
        LoginFrame fr= new LoginFrame();
        generate gen= new generate();
        String text =gen.getCaptcha();
        fr.captcha(text);
        String captcha = JOptionPane.showInputDialog(null, "Now enter the captcha!");
        if (text.equals(captcha)){
            fr.dispose();
            String s  = ("You are in!");
            Whatsapp whats = new Whatsapp();
            whats.whatsapp();
            JOptionPane.showMessageDialog(null,s);
        }else{
            JOptionPane.showInputDialog("Try again!");
        }
    }
}
