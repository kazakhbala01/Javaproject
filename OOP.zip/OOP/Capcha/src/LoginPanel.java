import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginPanel extends JPanel implements ActionListener {
    private final JTextField usernameField;
    private final JPasswordField passwordField;
    private final JButton loginButton;

    public LoginPanel() {
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        loginButton = new JButton("Login");

        loginButton.addActionListener(this);

        setLayout(new GridLayout(3, 2));
        add(new JLabel("Username:"));
        add(usernameField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(new JLabel(""));
        add(loginButton);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            REQ require = new REQ(password);
            LogPasscheck check = new LogPasscheck();
            if (password.length() >= 8) {
                if (require.ReqCheck()) {
                    if (check.LogPasscheck1(username, password)) {
                        Authorize authorize = new Authorize();
                        authorize.Authorize1();
                    } else {
                        JOptionPane.showMessageDialog(null, "Login or Password is not correct!");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Password should have at least 1 Upper lower case and 1 digit!");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Password should have more than 8 symbols!");
            }
        }
    }
}
