import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;

public class Whatsapp
{
    public void whatsapp(){
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI("https://graph.facebook.com/v13.0/102193072811662/messages"))
                    .header("Authorization", "Bearer EAAKU9ABYqY4BANHOiwtdAySON2JAXnPqZCAem4WwCZC80VXsSggv9vKrnoZCVmW6fYfvyVpJ0mOc9WaNJjCCqEJnKmobXDfXSXfPpZBRJvqjJxkZA1XBgt0MbtZA2J6heNAnHvXMCG2q9JdoAYGIYJqFPiU1FLQw8gHeXcZAWReiRevNWKG1wfFEcV1gIzr4OfjZAG4hertYe3g6DFBYGkX3")
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString("{ \"messaging_product\": \"whatsapp\", \"recipient_type\": \"individual\", \"to\": \"787083556776\", \"type\": \"template\", \"template\": { \"name\": \"java\", \"language\": { \"code\": \"en\" } } }"))
                    .build();
            HttpClient http = HttpClient.newHttpClient();
            HttpResponse<String> response = http.send(request,BodyHandlers.ofString());
            System.out.println(response.body());

        } catch (URISyntaxException | IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}