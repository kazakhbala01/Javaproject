public class LogPasscheck {
    public boolean LogPasscheck1(String username, String password){
        Encryption en=new Encryption();
        JDBC jd=new JDBC();
        String user=jd.getUsername();
        String pass = jd.getPass();
        String pass1=en.Hex(password);
        if (username.equals(user)&&pass1.equals(pass)){
            return true;
        }else{
            return false;
        }
    }
}
