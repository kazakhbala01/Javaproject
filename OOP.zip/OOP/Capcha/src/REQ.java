import java.util.regex.*;
public class REQ {
    public String pass;
    REQ(String password){
        this.pass=password;
    }
    public boolean ReqCheck(){
        String regex = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$";

        Pattern p = Pattern.compile(regex);
       if (pass == null) {
            return false;
        }
        Matcher m = p.matcher(pass);
        return m.matches();
}}
